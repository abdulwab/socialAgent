## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-012 (line 333) BLOCKER. Documentation Specialist required per AGENTS.md Documentation gate + 12207 6.5.10 Maintenance + SWEBOK Ch.7.

## Actual Task
Create:
1. `.orchestrated-agents/roles/technical-writer.md` -- specialist maker hat charter covering technical writing + audience adaptation + documentation structure + cross-linking
2. `oa-technical-writer` agent in `opencode.json` with stack-tagged `edit.permission` (`*`: deny, `*.md`: allow, env files deny)
3. Per-role permission smoke-test entry
4. Wire role display-name `Technical Writer` into `oa.ps1`

## Dependencies
Depends on GAP-J-F4 (socialhub-v8g.12).

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the broad `*.md` allowlist is correct (technical writer edits all markdown files).
- QA Strategist verifies smoke-test passes.
- Documentation Reviewer confirms the role can produce audience-adapted documentation (operator-facing, user-facing, contributor-facing).
- The new role can be invoked via oa.cmd run.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 333.
- AGENTS.md Documentation gate.
- 12207 6.5.10 Maintenance.

## Why This Is Useful
Without a Documentation Specialist maker hat, documentation updates are performed by ad-hoc Documentation Reviewer (adversary) comments, which is asymmetric. Closing GAP-K-012 provides a dedicated documentation maker hat that pairs with the Documentation Reviewer (adversary) for the standard maker-adversary loop. The role also ensures documentation keeps pace with implementation changes.