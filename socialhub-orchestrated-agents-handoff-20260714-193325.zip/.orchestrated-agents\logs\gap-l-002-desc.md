## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section L GAP-L-002 (line 365) PARTIAL. Routing-decision question: How does a role know which adversary is required for its risk class (security / privacy / performance / usability / accessibility / etc.)?

## Actual Task
Codify a risk-class-to-adversary map in:
- `.orchestrated-agents/workflows/adversarial-convergence.md` -- new section that lists each risk class and its required adversary role(s). E.g., risk class = security/privacy -> Security Privacy Reviewer required. Risk class = performance -> Performance Tester (adversary) + Release SRE Reviewer required. Risk class = usability/accessibility -> Accessibility Tester (adversary) + UX Designer (adversary) required.
- Optionally, new `.orchestrated-agents/workflows/risk-class-routing.md` -- standalone workflow if the adversarial-convergence.md amendment grows too large.

## Dependencies
Complements existing convergence rule in adversarial-convergence.md.

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the risk-class-to-adversary map is exhaustive (every Section A-G risk class has a corresponding adversary).
- QA Strategist verifies the map correctly identifies required adversaries for sample beads.
- Security Privacy Reviewer confirms the security/privacy risk class is correctly mapped (security-related beads must invoke SPR; privacy-related beads must invoke SPR + Privacy Governance).
- Documentation Reviewer confirms the new section is linked from CONTEXT.md.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 365 (GAP-L-002 row).
- .orchestrated-agents/workflows/adversarial-convergence.md (existing convergence rule).

## Why This Is Useful
Per-bead Role Selector matrices currently derive the risk-class-to-adversary mapping ad-hoc. Closing GAP-L-002 codifies the map so the mapping is consistent across beads and future Role Selector invocations can apply it uniformly.