## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section L GAP-L-004 (line 367) CONFIRMED GAP. Routing-decision question: How does the framework route beads by lifecycle phase (intake, design, build, deploy, operate)?

## Actual Task
Update `.orchestrated-agents/workflows/sdlc-gates.md` with phase-branch routing:
- Phase 1 Intake: gates 1-4 (intake and scope, business/mission analysis, stakeholder needs, requirements definition)
- Phase 2 Design: gates 5-7 (architecture impact, design definition, risk management)
- Phase 3 Build: gates 8-13 (security/privacy analysis, data/ownership analysis, implementation plan, construction/configuration, integration impact, verification strategy)
- Phase 4 Deploy: gates 14-15 (validation against user need, documentation and handoff)
- Phase 5 Operate: gates 16-19 (release/transition readiness, operations/observability/support, maintenance/rollback/disposal, compliance/policy impact)
- Phase 6 Process Improvement: gate 20 (process improvement opportunity)

Each phase gets a routing rule: which roles are required, which gates must be N/A or Already Satisfied vs Applicable, and which roles can declare phase completion.

## Dependencies
Complements existing sdlc-gates.md (20 gates listed sequentially, no phase routing).

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the phase-routing rules are exhaustive (every gate is in exactly one phase).
- QA Strategist verifies the phase-routing correctly classifies sample beads.
- Documentation Reviewer confirms the phase-routing is linked from CONTEXT.md Operating Model section.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 367 (GAP-L-004 row).
- .orchestrated-agents/workflows/sdlc-gates.md (current 20-gate sequential list).

## Why This Is Useful
Currently sdlc-gates.md lists 20 gates sequentially with no phase routing. Closing GAP-L-004 adds phase routing so Role Selector can determine which subset of gates applies to each bead based on its lifecycle phase. A design-only bead does not need gate 11 (construction) or gate 14 (validation); a build-only bead does not need gate 16 (release readiness). Phase routing reduces per-bead gate-evaluation overhead.