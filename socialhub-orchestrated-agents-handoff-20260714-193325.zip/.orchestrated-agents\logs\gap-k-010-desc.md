## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-010 (line 331) BLOCKER. Performance Tester required per ISO 25010:2023 GAP-D-002 Performance Efficiency + SWEBOK Ch.5 Testing (performance testing sub-techniques).

## Actual Task
Create:
1. `.orchestrated-agents/roles/perf-tester.md` -- specialist maker hat charter covering load testing + stress testing + spike testing + soak testing patterns
2. `oa-perf-tester` agent in `opencode.json` with stack-tagged `edit.permission` (`*`: deny, `fb_agent/tests/perf/**`: allow, `fb_dash/__tests__/perf/**`: allow, env files deny) + bash allow for `k6 *`, `locust *`, `wrk *`
3. Per-role permission smoke-test entry
4. Wire role display-name `Performance Tester` into `oa.ps1`

## Dependencies
Depends on GAP-K-006 (Test Engineer) = socialhub-v8g.22.12.

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the multi-path allowlist (fb_agent/tests/perf + fb_dash/__tests__/perf) + bash allowlist (k6 + locust + wrk) is correct.
- QA Strategist verifies smoke-test passes.
- Documentation Reviewer confirms the perf-tester role-charter is linked from ISO 25010 Performance Efficiency coverage.
- The new role can be invoked via oa.cmd run.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 331.
- ISO 25010:2023 GAP-D-002 Performance Efficiency.
- SWEBOK Ch.5 Testing.

## Why This Is Useful
Without a Performance Tester specialist hat, performance testing is folded into the QA Strategist (adversary) role, but the QA Strategist cannot run load tests (no bash allow for k6/locust/wrk). Closing GAP-K-010 provides a dedicated perf-testing maker hat with the appropriate bash allowlist. The role pairs with GAP-K-006 (Test Engineer) and GAP-K-009 (SRE Engineer) for performance observability.