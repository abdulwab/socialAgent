## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section L GAP-L-003 (line 366) CONFIRMED GAP. Routing-decision question: How does the framework prevent reuse of the same Maker Engineer across incompatible stacks (backend maker running frontend changes)?

## Actual Task
Generalize the oa-process-engineer stack-tagged template (opencode.json lines 267-275) to all specialist maker hats, and tighten oa-maker-engineer:
1. Update `.orchestrated-agents/roles/process-engineer.md` to document the stack-tagged template as the canonical pattern for specialist maker hats.
2. For each of the 17 specialist maker hats (GAP-K-001 through GAP-K-017), update the oa-* agent's `edit.permission` block in `opencode.json` to use the stack-tagged pattern (already done at GAP-K bead implementation time; this GAP-L-003 bead confirms the pattern is applied uniformly).
3. Tighten `oa-maker-engineer` (opencode.json lines 91-98) to use the stack-tagged template (e.g., `*: deny, <default-stack-glob>: allow, env: deny`). Choose the default stack glob based on the SocialHub primary stack: either `fb_dash/**` (frontend-primary) or `fb_agent/**` (backend-primary) or `**` with extra safety constraints.

## Dependencies
Depends on GAP-J-F4 (socialhub-v8g.12).

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms all 17 specialist maker hats use the stack-tagged template (no `*: allow` blanket permission).
- QA Strategist verifies the per-role permission smoke-test (per F4) passes for all 17 specialist maker hats.
- Security Privacy Reviewer confirms env files are denied for all specialist maker hats.
- Documentation Reviewer confirms the tightened oa-maker-engineer default is documented in CONTEXT.md.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 366 (GAP-L-003 row).
- opencode.json lines 91-98 (oa-maker-engineer current blanket `*: allow`).
- opencode.json lines 267-275 (oa-process-engineer stack-tagged template).

## Why This Is Useful
Currently oa-maker-engineer has blanket `edit.permission: *: allow` (opencode.json lines 91-98). This means a Maker Engineer invocation could edit any file including product code, env files, and the framework itself. Tightening oa-maker-engineer to a stack-tagged default reduces the blast radius if the role is invoked for a stack-specific bead. The 17 specialist maker hats already use the stack-tagged template (verified at GAP-K bead implementation time).