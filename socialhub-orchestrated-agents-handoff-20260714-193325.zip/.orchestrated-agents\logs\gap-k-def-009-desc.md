## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-DEF-009 (line 353) DEFERRED. Per Section 0.6(a): Process Engineer + Workflow Scout handle methodology selection ad-hoc; dedicated Modeling/Methodology hat adds value only when multiple methodologies are simultaneously in use.

## Actual Task
DEFERRED: Create `.orchestrated-agents/roles/methodology-lead.md` with multi-methodology adoption. The role covers SWEBOK Ch.11 Software Engineering Models and Methods + 12207 6.4.1 Life Cycle Model Management (methodology selection).

## Dependencies
Promote with multi-methodology adoption (i.e., when the framework must support Waterfall + Agile + DevOps simultaneously and needs a dedicated hat to choose between them per bead).

## Acceptance Criteria (for promotion)
- Trigger: multi-methodology adoption is decided.
- Process Engineer files the promotion bead (this GAP-K-DEF-009 transitions to CONFIRMED GAP / BLOCKER).

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 353 (GAP-K-DEF-009 DEFERRED row).
- SWEBOK Ch.11.
- 12207 6.4.1 Life Cycle Model Management.

## Why Deferred
Per 0.6(a): Process Engineer + Workflow Scout handle methodology selection ad-hoc. A dedicated Modeling/Methodology hat adds value only when multiple methodologies are simultaneously in use and the selection becomes complex enough to warrant a dedicated role.