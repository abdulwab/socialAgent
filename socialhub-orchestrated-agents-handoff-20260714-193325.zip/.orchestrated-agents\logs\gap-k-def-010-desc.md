## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-DEF-010 (line 354) DEFERRED. Per Section 0.6(a): DevOps Engineer (GAP-K-008) + Security Engineer (GAP-K-005) cover runtime hardening through code; dedicated workflow adds value when hardening spans multiple services.

## Actual Task
DEFERRED: Author `.orchestrated-agents/workflows/runtime-hardening.md` with multi-service deployment. The workflow covers NIST SSDF PW.9 Configure Software for Security (runtime hardening) + SAMM Implementation.Secure Deployment.

## Dependencies
Promote with multi-service deployment (i.e., when the deployment spans multiple services and runtime hardening must be coordinated across services).

## Acceptance Criteria (for promotion)
- Trigger: multi-service deployment is initiated.
- Process Engineer files the promotion bead (this GAP-K-DEF-010 transitions to CONFIRMED GAP / BLOCKER).

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 354 (GAP-K-DEF-010 DEFERRED row).
- NIST SSDF PW.9.
- SAMM Implementation.Secure Deployment.

## Why Deferred
Per 0.6(a): DevOps Engineer (GAP-K-008) + Security Engineer (GAP-K-005) cover runtime hardening through code at current SocialHub scale (single backend + single frontend). A dedicated multi-service runtime-hardening workflow adds value only when deployment spans multiple services and hardening must be coordinated.