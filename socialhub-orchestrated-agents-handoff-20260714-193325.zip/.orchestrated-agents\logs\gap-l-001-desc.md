## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section L GAP-L-001 (line 364) CONFIRMED GAP. Routing-decision question: How does Role Selector decide between generic Maker Engineer and a specialist maker (Frontend / Backend / Integration / Data / Security / Test / etc.)?

## Actual Task
Update:
1. `.orchestrated-agents/roles/role-selector.md` -- include specialist-hats knowledge (list all 17 specialist maker hats from GAP-K-001 through GAP-K-017) and the Section 0.6 decision rule
2. `.orchestrated-agents/templates/role-selection.md` -- include specialist-routing template (decision tree that asks: does the bead target a specific stack? If yes, route to the corresponding specialist maker hat. If no, route to oa-maker-engineer.)

## Dependencies
Depends on GAP-K-018 (routing-decisions.md umbrella) = socialhub-v8g.22.24.

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the specialist-routing decision tree is exhaustive (every GAP-K-NNN specialist hat has a routing rule).
- QA Strategist verifies the role-selection template produces correct role choices for sample scenarios (a frontend-only bead routes to Frontend Engineer, a backend-only bead routes to Backend Engineer, a cross-stack bead routes to Integration Engineer or Maker Engineer).
- Documentation Reviewer confirms the role-selector.md and role-selection.md changes are linked from CONTEXT.md.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 364 (GAP-L-001 row).
- Section K lines 317-356 (the 17 specialist maker hat BLOCKER rows).

## Why This Is Useful
Without specialist-hats routing knowledge, Role Selector invocations default to oa-maker-engineer which has blanket `*: allow` permission. This is unsafe: a bead requiring a frontend-only edit could be routed to oa-maker-engineer which can edit any file. Closing GAP-L-001 ensures Role Selector routes stack-specific beads to stack-specific specialists, which have stack-scoped `edit.permission` patterns.