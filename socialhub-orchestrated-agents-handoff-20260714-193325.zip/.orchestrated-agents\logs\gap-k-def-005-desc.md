## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-DEF-005 (line 349) DEFERRED. Per Section 0.6(a): no current release-archival or code-signing need; will be needed when product reaches production.

## Actual Task
DEFERRED: Author `.orchestrated-agents/workflows/release-integrity.md` at first production release. The workflow covers NIST SSDF PS.2 + PS.3 (release integrity + archival).

## Dependencies
Promote at first production release (i.e., when the SocialHub product reaches production and release archival + code-signing become requirements).

## Acceptance Criteria (for promotion)
- Trigger: first production release.
- Process Engineer files the promotion bead (this GAP-K-DEF-005 transitions to CONFIRMED GAP / BLOCKER).

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 349 (GAP-K-DEF-005 DEFERRED row).
- NIST SSDF PS.2 + PS.3.

## Why Deferred
Per 0.6(a): no current release-archival or code-signing need. The release integrity workflow adds value only when the product reaches production and release artifacts must be archived + signed for compliance + audit.