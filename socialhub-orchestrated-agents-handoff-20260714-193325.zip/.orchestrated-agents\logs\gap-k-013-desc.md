## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-013 (line 334) BLOCKER. Standards Research Analyst required; this bead itself demonstrates the recurring need for source-cited standards analysis (12207 6.3.5 QM + 6.4.7 QA + SWEBOK Ch.12).

## Actual Task
Create:
1. `.orchestrated-agents/roles/standards-research-analyst.md` -- specialist maker hat charter covering academic-style source citation + cross-standards reconciliation + authoritative-source verification + standards-version tracking
2. `oa-standards-research-analyst` agent in `opencode.json` with stack-tagged `edit.permission` (`*`: deny, `implementation-plan/**`: allow, `AGENTS.md`: allow, env files deny) + bash allow for `curl *`, `webfetch *`
3. Per-role permission smoke-test entry
4. Wire role display-name `Standards Research Analyst` into `oa.ps1`

## Dependencies
Depends on GAP-J-F4 (socialhub-v8g.12).

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the curl/webfetch bash allowlist is correct and the role does NOT have write access to product code (read-only on fb_dash/ and fb_agent/).
- QA Strategist verifies smoke-test passes for curl/webfetch.
- Documentation Reviewer confirms the source-citation pattern from this bead (socialhub-v8g.22.1 v3/v4 matrix) is documented in the new role charter.
- The new role can be invoked via oa.cmd run.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 334 (GAP-K-013 row).
- This bead socialhub-v8g.22.1 itself: 506-line canonical matrix with 100+ source citations.
- 12207 6.3.5 QM + 6.4.7 QA + SWEBOK Ch.12.

## Why This Is Useful
The matrix at .orchestrated-agents/docs/coverage-matrix-v3.md took 4+ hours to assemble and required 4 adversary roles to converge. Without a Standards Research Analyst specialist hat, future standards-coverage analysis (e.g., when ISO 25010:2023 is superseded, or when SWEBOK v5 lands) will fall back on ad-hoc Process Engineer invocations, which lack the academic citation discipline. Closing GAP-K-013 provides a dedicated standards research maker hat with curl/webfetch bash allowlist for live source verification.