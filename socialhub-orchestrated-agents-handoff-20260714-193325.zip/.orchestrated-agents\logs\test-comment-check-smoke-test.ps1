#requires -Version 5.1
<#
.SYNOPSIS
    Smoke test for .orchestrated-agents/bin/test-comment-check.ps1.

.DESCRIPTION
    Runs all 6 historical probe-comment patterns from socialhub-v8g.22.44
    plus a compliant control case through the linter, and reports PASS/FAIL
    per case based on expected exit code and valid flag.

    Exit codes:
      0  - all 6 probes rejected (exit 1) AND control accepted (exit 0)
      1  - one or more cases diverged from expectations; linter has regressed
           OR the documented expectations are stale
#>
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"

$LinterPath = Join-Path $PSScriptRoot "..\bin\test-comment-check.ps1"
$LinterPath = (Resolve-Path $LinterPath).Path

$cases = @(
    @{ Id = 1; Name = "test probe (Role Selector 11:19Z)"; Author = "Role Selector"; Text = "test probe"; ExpectValid = $false; ExpectExit = 1 },
    @{ Id = 2; Name = "line1/line2/line3 (Role Selector 11:19Z)"; Author = "Role Selector"; Text = "line1`nline2`nline3"; ExpectValid = $false; ExpectExit = 1 },
    @{ Id = 3; Name = "Test line 1/2/3 (Adversarial Reviewer 12:05Z)"; Author = "Adversarial Reviewer"; Text = "Test line 1`nTest line 2`nTest line 3"; ExpectValid = $false; ExpectExit = 1 },
    @{ Id = 4; Name = "hello world (Adversarial Reviewer 12:06Z)"; Author = "Adversarial Reviewer"; Text = "hello world"; ExpectValid = $false; ExpectExit = 1 },
    @{ Id = 5; Name = "test with id and pattern (Adversarial Reviewer 12:07Z)"; Author = "Adversarial Reviewer"; Text = "test with <id> and <pattern>"; ExpectValid = $false; ExpectExit = 1 },
    @{ Id = 6; Name = "lineA/lineB/lineC with id literal (Adversarial Reviewer 12:07Z)"; Author = "Adversarial Reviewer"; Text = "lineA`nlineB`nlineC with <id> literal"; ExpectValid = $false; ExpectExit = 1 },
    @{ Id = 7; Name = "compliant control (positive case)"; Author = "Process Engineer"; Text = @"
### Commentor: Process Engineer

**Step/Subtask:** Comment-Discipline Self-Check smoke-test positive control

**Status:** Evidence Accepted

**Findings:** This comment is intentionally structured as a valid Markdown work record with all required fields and sufficient length to satisfy the linter. It serves as the positive control for the smoke test above; the negative cases (1-6) MUST all fail, this case MUST pass.

**Evidence:** Copy-paste this comment into a here-string and pipe to test-comment-check.ps1.

**Required Next Action:** Confirm exit code is 0; if not, the linter has regressed.
"@; ExpectValid = $true; ExpectExit = 0 },
    @{ Id = 8; Name = "documentation comment with backtick-wrapped probe phrases (positive case, backtick-stripping exemption)"; Author = "Process Engineer"; Text = @'
### Commentor: Process Engineer

**Step/Subtask:** Backtick-stripping exemption smoke-test

**Status:** Evidence Accepted

**Findings:** This comment documents the C4 fix list and references historical probe-comment patterns as literal examples inside backticks. Specifically, it mentions the probe phrases `test probe`, `hello world`, `lineA`, `lineB`, `lineC`, and the literal patterns `line1`, `line2`, `line3`. All such references are inside backticks and MUST be exempted from probe-phrase detection by the backtick-stripping logic in test-comment-check.ps1.

**Evidence:** Direct invocation of the linter on this here-string via the smoke-test runner.

**Required Next Action:** Confirm exit code is 0.
'@; ExpectValid = $true; ExpectExit = 0 }
)

$results = @()
$allPass = $true

foreach ($case in $cases) {
    # Use a temp file to avoid PowerShell here-string / -Text multi-line
    # value binding quirks. Write the comment text to a temp file, then
    # read it back via Get-Content -Raw and pipe to the linter. The temp
    # file uses ASCII encoding to avoid BOM contamination (Set-Content
    # -Encoding utf8 inserts a BOM in PowerShell 5.1).
    $tempFile = Join-Path $env:TEMP ("case-" + $case.Id + "-" + [guid]::NewGuid() + ".md")
    [System.IO.File]::WriteAllText($tempFile, $case.Text, [System.Text.Encoding]::ASCII)

    $rawOutput = Get-Content -Raw -LiteralPath $tempFile | & $LinterPath -BeadId "socialhub-v8g.22.44" -Author $case.Author
    $exitCode = $LASTEXITCODE

    Remove-Item -LiteralPath $tempFile -ErrorAction SilentlyContinue

    $output = $rawOutput | ConvertFrom-Json
    $passed = (($output.valid -eq $case.ExpectValid) -and ($exitCode -eq $case.ExpectExit))
    if (-not $passed) { $allPass = $false }
    $results += [PSCustomObject]@{
        Id            = $case.Id
        Name          = $case.Name
        ExpectValid   = $case.ExpectValid
        ActualValid   = $output.valid
        ExpectExit    = $case.ExpectExit
        ActualExit    = $exitCode
        Pass          = $passed
        Violations    = ($output.violations -join "; ")
    }
}

$results | Format-Table -AutoSize -Wrap | Out-String | Write-Host

Write-Host ""
Write-Host "SUMMARY:"
$passCount = ($results | Where-Object { $_.Pass }).Count
$totalCount = $results.Count
Write-Host "  Passed: $passCount / $totalCount"

if ($allPass) {
    Write-Host "  Overall: PASS (linter correctly rejects all 6 probe patterns AND accepts the compliant control)"
    exit 0
} else {
    Write-Host "  Overall: FAIL (linter regression or stale expectations; investigate above)"
    exit 1
}