## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-DEF-003 (line 347) DEFERRED. Per Section 0.6(a): capacity planning is a current-gap but does not block product-code readiness at current SocialHub scale.

## Actual Task
DEFERRED: Create `.orchestrated-agents/roles/capacity-planner.md` when traffic warrants. The role covers SRE Part II Ch.21 Handling Overload + Ch.22 Addressing Cascading Failures + SFIA Delivery and Operation (CPMG sub-skill).

## Dependencies
Promote when traffic warrants (i.e., when current ad-hoc capacity decisions become too frequent or high-stakes).

## Acceptance Criteria (for promotion)
- Trigger: traffic reaches a threshold where weekly capacity reviews are needed.
- Process Engineer files the promotion bead (this GAP-K-DEF-003 transitions to CONFIRMED GAP / BLOCKER).

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 347 (GAP-K-DEF-003 DEFERRED row).
- SRE Part II Ch.21-22.

## Why Deferred
Per 0.6(a): capacity planning is a current-gap but does not block product-code readiness at current SocialHub scale. The SRE Engineer (GAP-K-009) and Release SRE Reviewer (adversary) can handle capacity decisions until traffic scales beyond ad-hoc review.