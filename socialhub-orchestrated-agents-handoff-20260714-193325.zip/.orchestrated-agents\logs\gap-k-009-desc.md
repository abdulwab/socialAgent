## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-009 (line 330) BLOCKER. SRE specialist required per 12207 6.5.9 Operation + SRE Part II 7 Principles + AGENTS.md Operations gate.

## Actual Task
Create:
1. `.orchestrated-agents/roles/sre-engineer.md` -- specialist maker hat charter covering SLO/SLI definition + error-budget policy + observability + rollback + on-call patterns
2. `oa-sre-engineer` agent in `opencode.json` with stack-tagged `edit.permission` (`*`: deny, observability config files: allow, env files deny) + bash allow for `kubectl *`, `terraform *`
3. Per-role permission smoke-test entry
4. Wire role display-name `SRE Engineer` into `oa.ps1`

## Dependencies
Depends on GAP-J-F4 (socialhub-v8g.12). Pairs with GAP-K-008 (DevOps Engineer).

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the observability-config allowlist is correct (alertmanager, prometheus, grafana, etc.) and does not include destructive terraform commands like `terraform destroy` without confirmation.
- QA Strategist verifies smoke-test passes for kubectl and terraform commands.
- Release SRE Reviewer confirms the SRE role charter is consistent with their own adversarial role.
- The new role can be invoked via oa.cmd run.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 330.
- Google SRE Book Part II 7 Principles (Eliminating Toil, Monitoring Distributed Systems, etc.).
- AGENTS.md Operations gate.

## Why This Is Useful
Without an SRE specialist hat, observability and rollback are performed by ad-hoc Maker Engineer invocations, which risks unsafe production operations. Closing GAP-K-009 routes operational concerns through a dedicated role that has bash allow for kubectl/terraform but maintains the deny rules for production-destructive operations. The role also documents the SLO/SLI patterns for future contributors.