## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-017 (line 338) BLOCKER. Privacy/Governance/Compliance maker required for production data-processing agreements per 12207 6.3.5 QM + SAMM Governance.Policy & Compliance + AGENTS.md Clerk + LangSmith + Z.AI GLM data flows + GDPR/CCPA.

## Actual Task
Create:
1. `.orchestrated-agents/roles/privacy-governance.md` -- specialist maker hat charter covering GDPR/CCPA compliance + data-processing agreements + privacy policy + governance documentation + audit-trail
2. `oa-privacy-governance` agent in `opencode.json` with stack-tagged `edit.permission` (`*`: deny, `*.md`: allow, `implementation-plan/**`: allow, env files deny) + read-only access to all product code (via cat / rg / git status etc. but no edit rights to fb_dash/ or fb_agent/)
3. Per-role permission smoke-test entry
4. Wire role display-name `Privacy Governance` into `oa.ps1`

## Dependencies
Depends on GAP-J-F4 (socialhub-v8g.12). Pairs with GAP-K-005 (Security Engineer).

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the read-only-product-code pattern is enforced.
- QA Strategist verifies smoke-test passes.
- Security Privacy Reviewer confirms the role-charter aligns with their own adversary scope.
- Documentation Reviewer confirms GDPR/CCPA coverage is documented.
- The new role can be invoked via oa.cmd run.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 338.
- 12207 6.3.5 QM.
- SAMM Governance.Policy & Compliance.
- AGENTS.md Clerk + LangSmith + Z.AI GLM data flows.
- GDPR + CCPA.

## Why This Is Useful
Without a Privacy/Governance maker hat, GDPR/CCPA compliance documentation is folded into Security Privacy Reviewer (adversary) which lacks the maker authority to author data-processing agreements. Closing GAP-K-017 provides a dedicated privacy/governance maker hat that pairs with the Security Privacy Reviewer (adversary) for the standard maker-adversary loop. The role pairs with GAP-K-005 (Security Engineer) for security-and-privacy alignment.