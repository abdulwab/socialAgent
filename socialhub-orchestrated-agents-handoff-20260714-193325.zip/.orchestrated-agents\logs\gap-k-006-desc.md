## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-006 (line 327) BLOCKER. Test specialist required per 12207 6.5.6 Verification + 6.5.7 Validation + AGENTS.md Verification gate + pytest + npm test.

## Actual Task
Create:
1. `.orchestrated-agents/roles/test-engineer.md` -- specialist maker hat charter covering pytest pattern + npm test pattern + e2e pattern + lint enforcement
2. `oa-test-engineer` agent in `opencode.json` with stack-tagged `edit.permission` (`*`: deny, `fb_agent/tests/**`: allow, `fb_dash/__tests__/**`: allow, env files deny) + `pytest*` + `npm test*` + `npm run lint*` bash allow
3. Per-role permission smoke-test entry (per F4)
4. Wire role display-name `Test Engineer` into `oa.ps1`

## Dependencies
Depends on GAP-J-F4 (socialhub-v8g.12).

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the two-path allowlist (fb_agent/tests + fb_dash/__tests__) + bash allowlist for pytest/npm test/npm run lint is correct.
- QA Strategist verifies smoke-test passes for all 3 bash allowlist commands.
- Documentation Reviewer confirms the test role-charter is linked from AGENTS.md Verification section.
- The new role can be invoked via `oa.cmd run`.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 327.
- AGENTS.md Verification section: pytest + npm run lint + npm run build + npm test.
- F4 bead socialhub-v8g.12 (Per-role permission smoke-test scaffolding).

## Why This Is Useful
Without a Test Engineer specialist hat, the QA Strategist (adversary only) has no maker counterpart to actually write tests. The framework has a test critique role but no test author role, which is asymmetric and slows verification cycles. Closing GAP-K-006 provides the missing maker hat so QA Strategist can request test additions through a normal maker-adversary loop instead of doing the work itself.