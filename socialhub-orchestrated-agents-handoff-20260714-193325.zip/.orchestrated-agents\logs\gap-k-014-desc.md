## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-014 (line 335) BLOCKER. Product Manager / Product Owner required per 12207 6.5.1 Stakeholder Needs + Scrum Guide 2020 Product Owner + AGENTS.md acceptance-criteria authoring.

## Actual Task
Create:
1. `.orchestrated-agents/roles/product-manager.md` -- specialist maker hat charter covering acceptance-criteria authoring + stakeholder needs analysis + roadmap + user-story authoring + prioritization
2. `oa-product-manager` agent in `opencode.json` with stack-tagged `edit.permission` (`*`: deny, `implementation-plan/**`: allow, `AGENTS.md`: allow, env files deny)
3. Per-role permission smoke-test entry
4. Wire role display-name `Product Manager` into `oa.ps1`

## Dependencies
Depends on GAP-J-F4 (socialhub-v8g.12). Pairs with GAP-K-015 (Requirements Engineer).

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the implementation-plan-only allowlist is correct (PM does not edit product code).
- QA Strategist verifies smoke-test passes.
- Documentation Reviewer confirms the role-charter links from AGENTS.md acceptance-criteria section.
- The new role can be invoked via oa.cmd run.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 335.
- Scrum Guide 2020 Product Owner accountability.
- 12207 6.5.1 Stakeholder Needs.
- AGENTS.md acceptance-criteria authoring section.

## Why This Is Useful
Without a Product Manager specialist hat, acceptance-criteria authoring is folded into Role Selector (which is a process architect role, not a product owner role). Closing GAP-K-014 provides a dedicated product manager maker hat that owns the acceptance-criteria and stakeholder-needs inputs to each bead. The role pairs with GAP-K-015 (Requirements Engineer) for full requirements coverage.