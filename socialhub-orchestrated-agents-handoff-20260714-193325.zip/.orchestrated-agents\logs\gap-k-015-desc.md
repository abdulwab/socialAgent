## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-015 (line 336) BLOCKER. Business Analyst / Requirements Engineer required per 12207 6.5.1 Stakeholder Needs + 6.5.2 Requirements Analysis + SWEBOK Ch.1 + SFIA Strategy and Architecture.

## Actual Task
Create:
1. `.orchestrated-agents/roles/requirements-engineer.md` -- specialist maker hat charter covering requirements elicitation + requirements analysis + requirements specification + traceability matrix + use-case authoring
2. `oa-requirements-engineer` agent in `opencode.json` with stack-tagged `edit.permission` (`*`: deny, `implementation-plan/**`: allow, `AGENTS.md`: allow, env files deny)
3. Per-role permission smoke-test entry
4. Wire role display-name `Requirements Engineer` into `oa.ps1`

## Dependencies
Depends on GAP-J-F4 (socialhub-v8g.12). Pairs with GAP-K-014 (Product Manager).

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the implementation-plan-only allowlist is correct (Requirements Engineer does not edit product code).
- QA Strategist verifies smoke-test passes.
- Documentation Reviewer confirms traceability matrix and use-case patterns are documented.
- The new role can be invoked via oa.cmd run.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 336.
- 12207 6.5.1 Stakeholder Needs + 6.5.2 Requirements Analysis.
- SWEBOK Ch.1 Software Requirements.
- SFIA Strategy and Architecture.

## Why This Is Useful
Without a Requirements Engineer specialist hat, requirements analysis is folded into Role Selector (process architect role, not a requirements engineer role). Closing GAP-K-015 provides a dedicated requirements engineer maker hat that owns the requirements elicitation/analysis/specification inputs to each bead. The role pairs with GAP-K-014 (Product Manager) for full requirements coverage and complements GAP-K-013 (Standards Research Analyst) for source-cited requirements baselines.