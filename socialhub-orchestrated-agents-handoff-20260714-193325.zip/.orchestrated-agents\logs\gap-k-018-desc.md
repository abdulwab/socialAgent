## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-018 (line 339) BLOCKER. Routing-decision workflows required so Role Selector can reliably choose the right hat.

## Actual Task
Author:
1. `.orchestrated-agents/workflows/routing-decisions.md` -- the canonical routing-decision workflow file that codifies all 6 routing-decision questions from Section L (GAP-L-001 through GAP-L-006)
2. Updates to `.orchestrated-agents/roles/role-selector.md` -- include specialist-hats knowledge so Role Selector can choose between generic Maker Engineer and specialist maker (Frontend / Backend / Integration / Data / Security / Test / etc.)
3. Updates to `.orchestrated-agents/templates/role-selection.md` -- include specialist-routing template
4. Cross-link the new routing-decisions.md from `.orchestrated-agents/docs/CONTEXT.md` Operating Model section

## Dependencies
Depends on GAP-K-001 through GAP-K-017 (the routing needs the specialists to route to). All 17 specialist-hat beads must be at least in-progress before this routing umbrella lands. The 6 GAP-L-NNN routing-decision beads (socialhub-v8g.22.36 through socialhub-v8g.22.41) depend on this GAP-K-018 umbrella.

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms all 6 routing-decision questions (Section L) are addressed in routing-decisions.md.
- QA Strategist verifies the role-selection template produces correct role choices for sample scenarios.
- Documentation Reviewer confirms the routing-decisions.md is linked from CONTEXT.md and is understandable by future Role Selector invocations.
- A test scenario: a future bead requiring a backend FastAPI edit correctly routes to oa-backend-engineer, NOT to oa-maker-engineer.
- The new workflow file is exercisable: Role Selector can quote the routing decision with evidence-backed citation to routing-decisions.md.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 339 (GAP-K-018 row).
- Section L lines 358-371 (GAP-L-001 through GAP-L-006 routing-decision questions).
- .orchestrated-agents/roles/role-selector.md (current charter).
- .orchestrated-agents/templates/role-selection.md (current template).
- .orchestrated-agents/docs/CONTEXT.md Operating Model section.

## Why This Is Useful
Without routing-decision workflows, Role Selector invocations rely on per-bead manual reasoning. Closing GAP-K-018 codifies the routing logic so the framework can scale to many specialist hats without ad-hoc routing decisions. The role-selection template becomes a reusable artifact that future Role Selector invocations can apply uniformly.