### Commentor: Process Engineer [Part 1 of 4 -- v3 Consolidated Canonical Matrix: Frontmatter + Sections A-B]

**Step/Subtask:** Publish a consolidated canonical v3 matrix addressing the 6 Needs Fix items raised by QA Strategist.

**Status:** In Progress**Section 0 -- v3 Frontmatter (supersedes v1 + v2)

**0.1 Scope statement.** v3 maps current `.orchestrated-agents/` coverage against nine authoritative source baselines pre-supplied by parent epic `socialhub-v8g.22` and explicitly demanded by the bead description and the Role Selector comment at 2026-07-12 22:13:17Z. The nine sources are: (1) ISO/IEC/IEEE 12207:2017 [with 2026 currency note], (2) NIST SSDF SP 800-218 v1.1, (3) OWASP SAMM v2, (4) ISO/IEC 25010:2023, (5) IEEE SWEBOK Guide V4.0, (6) SFIA 9, (7) Google SRE Book Part II Principles, (8) Scrum Guide 2020, plus the authoritative internal source (9) `.orchestrated-agents/` files plus `opencode.json`.

**0.2 Currency notes (corrects v1 errors confirmed by authoritative sources this turn):**

- **ISO/IEC/IEEE 12207:2017 is WITHDRAWN.** Verified via https://www.iso.org/standard/63712.html: "Status: Withdrawn" / "Stage: 95.99" / "Withdrawal date: 2026-04-29" / "New version available: ISO/IEC/IEEE 12207:2026" (https://www.iso.org/standard/90219.html, Published). The bead explicitly demands the 2017 mapping (the original baseline), so v3 retains 12207:2017 as the source of truth but adds the 2026 currency note: any new 12207:2017 row that maps to a renamed/restructured process in 12207:2026 must be cross-referenced to the 2026 clause so that Workflow Scout follow-up beads can be authored against either edition without re-deriving the mapping.

- **ISO/IEC 25010:2011 is WITHDRAWN; ISO/IEC 25010:2023 supersedes it.** Verified via https://www.iso.org/standard/78176.html: "Life cycle: Previously -- Withdrawn -- ISO/IEC 25010:2011 / Now -- Published -- ISO/IEC 25010:2023" / abstract states "the product quality model is composed of nine characteristics." The v1 matrix used the 2011 8-characteristic model (Functional Suitability / Performance / Compatibility / Usability / Reliability / Security / Maintainability / Portability) which is the obsolete taxonomy. v3 uses the 2023 9-characteristic model and lists all 9.

- **IEEE SWEBOK v4 has 18 KAs, not 15.** Verified via https://www.computer.org/education/bodies-of-knowledge/software-engineering/topics: "SWEBOK V4.0 comprises 18 Knowledge Areas, plus a new Appendix on Standards" and the table of contents enumerates Ch.1 Requirements, Ch.2 Architecture, Ch.3 Design, Ch.4 Construction, Ch.5 Testing, Ch.6 Engineering Operations, Ch.7 Maintenance, Ch.8 Configuration Management, Ch.9 Management, Ch.10 Process, Ch.11 Models and Methods, Ch.12 Quality, Ch.13 Security, Ch.14 Professional Practice, Ch.15 Economics, Ch.16 Computing Foundations, Ch.17 Mathematical Foundations, Ch.18 Engineering Foundations. v1 omitted Architecture (Ch.2), Engineering Operations (Ch.6), and Engineering Foundations (Ch.18).

- **Google SRE Book Part II has 7 Principles, not 6.** Verified via https://sre.google/sre-book/part-II-principles/ table of contents: Ch.3 Embracing Risk, Ch.4 Service Level Objectives, Ch.5 Eliminating Toil, Ch.6 Monitoring Distributed Systems, Ch.7 The Evolution of Automation at Google, Ch.8 Release Engineering, Ch.9 Simplicity. v1 omitted Risk (Ch.3), Automation (Ch.7), and Simplicity (Ch.9).

- **NIST SSDF PW.8 is security testing of executable code, not generic test coverage.** NIST SP 800-218 v1.1 PW.8 (Test Executable Code) practice description is "Test executable code to identify vulnerabilities and verify compliance with security requirements." v1 mapped PW.8 to Performance/Compatibility/Usability/Reliability/Maintainability/Portability tests -- which are ISO/IEC 25010 quality characteristics, not SSDF security-test practices. v3 re-maps PW.8 to security-test capability gaps (DAST, fuzzing, abuse-case testing, security-requirement traceability) and explicitly notes that the ISO 25010 characteristic coverage gaps belong in Section D, not in PW.8.

- **OWASP SAMM v2 has 5 business functions x 3 security practices = 15 practices.** Verified via https://owaspsamm.org/model/ "OWASP SAMM defines five business functions and fifteen security practices." v1 already had all 15 -- no correction needed, but the practice-level total is now stated explicitly.

- **Scrum Guide 2020 has 3 accountabilities (Developers, Product Owner, Scrum Master) + 3 artifact commitments (Product Goal, Sprint Goal, Definition of Done).** Verified via https://scrumguides.org/scrum-guide.html "Scrum defines three specific accountabilities within the Scrum Team: the Developers, the Product Owner, and the Scrum Master" plus the artifact-commitment paragraph "For the Product Backlog it is the Product Goal. For the Sprint Backlog it is the Sprint Goal. For the Increment it is the Definition of Done." v1 conflated accountabilities and artifact commitments in a single "Scrum Accountabilities" row -- v3 separates them.

**0.3 Stable gap-ID convention.** Every row in Sections A-I gets a stable gap ID of the form `GAP-<SectionLetter>-<NNN>`, e.g., `GAP-A-001` is the first row in Section A. Section K rows get IDs of the form `GAP-K-<NNN>` (blockers) and `GAP-K-IMP-<NNN>` (improvements) and `GAP-K-DEF-<NNN>` (deferred). Section J rows keep the existing F1/F2/.../N3 file-bead IDs (no renumbering -- these are already filed Beads). This is what QA Strategist item 4 ("Section K is not an auditable gap register") and item 6 ("append-only merge is an edge-risk") demanded: stable, atomic IDs that Workflow Scout can file 1:1 against.

**0.4 Per-row evidence contract (corrects v1/v2 weakness QA Strategist item 2).** Every row must cite:
- **Source**: URL + section anchor or chapter reference. No bare landing pages.
- **Repository artifact**: file path (relative to repo root) + heading or line range. Or "no artifact" if absent.
- **Verdict**: one of COVERED / PARTIAL / CONFIRMED GAP / N/A (out-of-AI-agent-scope). Each verdict has a one-line rationale.
- **Disposition (Section K only)**: BLOCKER / IMPROVEMENT / DEFERRED + 1-line rationale.

**0.5 Distinction between N/A, DEFERRED, and missing-role (corrects QA Strategist item 5).** These are three separate states with different downstream consequences:
- **N/A (out of AI-agent scope):** The standard requires a function that has no AI-agent analogue in any currently-imagined framework (e.g., HR management, vendor procurement, mathematical foundations). Workflow Scout does NOT file a follow-up bead. Recorded for traceability.
- **DEFERRED (improvement, not blocker):** A capability could be added but is not required for product-code readiness today. Workflow Scout files a P2/P3 follow-up bead that Workflow Scout would not work on until the blocker list is empty.
- **CONFIRMED GAP (blocker):** A capability is required for product-code readiness but is not currently in the framework. Workflow Scout files a P0/P1 follow-up bead that must be worked on before the next product-code bead closes.

**0.6 Decision rule for generic Maker Engineer vs specialist maker (corrects QA Strategist item 5).** A specialist maker hat is REQUIRED (CONFIRMED GAP) when all three of: (a) the standard or product-code work item demands domain knowledge that generic Maker Engineer does not carry (e.g., SQLAlchemy Alembic migration authoring for the data specialist, Clerk JWT validation patterns for the security specialist), AND (b) the work item is on the active SocialHub stack boundary (frontend `fb_dash`, backend `fb_agent`, LangGraph runtime, PostgreSQL), AND (c) the work item changes more than ~50 lines of code OR introduces a new file under a non-shared path. A specialist is NOT required when: (a) generic Maker Engineer suffices (e.g., small bug fixes, docstring updates, single-file refactors), OR (b) the work item is in a shared path (e.g., `implementation-plan/`, root-level config), OR (c) the work item is a one-line change. This decision rule is invoked by Role Selector on every product-code bead and is recorded in the Section K rationale for each must-have-now specialist hat.

**0.7 v3 - v1/v2 delta summary.** v3 is canonical; v1 and v2 remain in the bead history for audit. The deltas are:
- Section A: 12207:2017 retained as baseline; added 2026 currency note; Section A0 footnote on enumeration scope.
- Section B: PW.8 re-mapped from generic test coverage to security-test capability gaps; process-timing gap noted for PW.7 (per Adversarial Reviewer defect #4 already applied in v2).
- Section C: All 15 SAMM practices retained; verdict consistency check applied.
- Section D: ISO/IEC 25010:2023 9-characteristic model (replacing 2011 8-characteristic model); each row cites the 2023 chapter/section anchor.
- Section E: SWEBOK v4 18-KA model (replacing v1 15-KA model); Architecture, Engineering Operations, and Engineering Foundations added.
- Section F: SFIA categories retained; sub-skill evidence expanded where QA Strategist item 5 demanded evidence of supplier / project / measurement / quality / operations / testing / governance skills.
- Section G: SRE Part II 7-Principle model (replacing v1 6-row taxonomy); Embracing Risk, Automation, and Simplicity added.
- Section H: Scrum accountabilities (3) separated from artifact commitments (3).
- Section I: Specialist maker hat list consolidated and reduced to atomic rows (no bundling).
- Section J: existing F-bead IDs retained; per-row evidence expanded with file path + line range.
- Section K: atomic rows (no bundling); stable GAP-K-NNN / GAP-K-IMP-NNN / GAP-K-DEF-NNN IDs; decision rule from 0.6 above cited per row.
- Section L: routing-decision rows consolidated to 6 atomic questions.
- Section M: source URLs consolidated.
- Section N: conformance statement updated to reflect v3 supersession of v1 and v2.

(Continued in Part 2: Section A table rows)

**Section A -- ISO/IEC/IEEE 12207:2017 Software life cycle processes (with 2026 currency note)**

Baseline: ISO/IEC/IEEE 12207:2017 (https://www.iso.org/standard/63712.html), Status: Withdrawn, Withdrawal date: 2026-04-29, Superseded by ISO/IEC/IEEE 12207:2026 (https://www.iso.org/standard/90219.html, Published). The 2017 edition is retained per the bead description; v3 adds 2026 cross-references where clause numbering differs. Four process groups per 12207:2017 (Agreement / Organization Project-Enabling / Technical Management / Technical).

| Gap ID | Process | Source anchor (12207:2017) | Repository artifact | Verdict | Rationale |
| --- | --- | --- | --- | --- | --- |
| GAP-A-001 | 6.2.1 Acquisition (Agreement) | 12207:2017 Clause 6.2.1 | no artifact | CONFIRMED GAP | No Acquisition/Supplier/Vendor/Procurement hat; out-of-AI-scope for vendor selection but PARTIAL relevance for tool/dependency acquisition |
| GAP-A-002 | 6.2.2 Supply (Agreement) | 12207:2017 Clause 6.2.2 | no artifact | N/A | Supply process (delivery of product to acquirer) is out of AI-agent scope for socialhub internal product |
| GAP-A-003 | 6.3.1 Life Cycle Model Management | 12207:2017 Clause 6.3.1 | `.orchestrated-agents/roles/process-engineer.md` line 5 (workflow/control-plane maker) | PARTIAL | Process Engineer manages the framework own life cycle (role files, workflow files) but no explicit life-cycle model management artifact for product code |
| GAP-A-004 | 6.3.2 Infrastructure Management | 12207:2017 Clause 6.3.2 | `.orchestrated-agents/roles/release-sre-reviewer.md` line 1-15 (Release SRE Reviewer, adversary only) | CONFIRMED GAP | No Platform/Infrastructure maker hat; adversary-only review cannot drive provisioning |
| GAP-A-005 | 6.3.3 Portfolio Management | 12207:2017 Clause 6.3.3 | no artifact | N/A | Out of AI-agent scope (PMO function) |
| GAP-A-006 | 6.3.4 Human Resource Management | 12207:2017 Clause 6.3.4 | no artifact | N/A | Out of AI-agent scope (HR function) |
| GAP-A-007 | 6.3.5 Quality Management (organizational: policy, measurement, audit) | 12207:2017 Clause 6.3.5 (NOT to be confused with 6.4.7 Quality Assurance) | `.orchestrated-agents/roles/qa-strategist.md` lines 1-23 (QA Strategist covers project-level QA = 6.4.7, not organizational QM = 6.3.5) | PARTIAL | QA Strategist covers project-level Quality Assurance (6.4.7) but the organizational Quality Management (6.3.5) function (policy, measurement, audit) is not covered. The 6.3.5 PARTIAL verdict is correct; v1 evidence field conflated the two clauses -- v3 separates them |
| GAP-A-008 | 6.3.6 Knowledge Management | 12207:2017 Clause 6.3.6 | `.orchestrated-agents/roles/process-engineer.md` line 5 (partial: workflow knowledge only) + `.orchestrated-agents/docs/CONTEXT.md` (project knowledge documentation, partial) | PARTIAL | No dedicated KM workflow; Process Engineer partial; framework doc partial |
| GAP-A-009 | 6.4.1 Project Planning | 12207:2017 Clause 6.4.1 | `.orchestrated-agents/roles/role-selector.md` (Project Planning perspective in role-selection debate, partial) | PARTIAL | No dedicated Project Manager maker hat |
| GAP-A-010 | 6.4.2 Project Assessment and Control | 12207:2017 Clause 6.4.2 | no artifact | N/A | Out of AI-agent scope for project assessment |
| GAP-A-011 | 6.4.3 Decision Management | 12207:2017 Clause 6.4.3 | `.orchestrated-agents/workflows/human-input.md` (HQF invokes when decision needed) + `.orchestrated-agents/roles/human-question-framer.md` | COVERED | HQF covers decision management via human-input protocol |
| GAP-A-012 | 6.4.4 Risk Management | 12207:2017 Clause 6.4.4 | `.orchestrated-agents/workflows/sdlc-gates.md` Gate 7 (Risk management) + `.orchestrated-agents/roles/security-privacy-reviewer.md` (adversary) | PARTIAL | Gate defined; no dedicated Risk Manager maker hat |
| GAP-A-013 | 6.4.5 Configuration Management | 12207:2017 Clause 6.4.5 | `.orchestrated-agents/roles/process-engineer.md` line 5 (manages `.orchestrated-agents/**` framework configuration) + `opencode.json` (editable by Process Engineer, framework configuration file) | PARTIAL | Process Engineer manages framework configuration files (`.orchestrated-agents/**`, `opencode.json`) but no CM hat for product code (source/version/release artifacts in `fb_agent/` and `fb_dash/`) |
| GAP-A-014 | 6.4.6 Information Management | 12207:2017 Clause 6.4.6 | no artifact | CONFIRMED GAP | No Information Manager hat (logs, telemetry, observability are partial SRE coverage) |
| GAP-A-015 | 6.4.7 Quality Assurance (project-level) | 12207:2017 Clause 6.4.7 | `.orchestrated-agents/roles/qa-strategist.md` lines 1-23 (QA Strategist role charter) | COVERED | QA Strategist covers project-level QA; see GAP-A-007 for organizational QM distinction |
| GAP-A-016 | 6.4.8 Measurement | 12207:2017 Clause 6.4.8 | no artifact | CONFIRMED GAP | No Measurement hat; deferred for product-code readiness (K-DEFERRED bucket) |
| GAP-A-017 | 6.5.1 Stakeholder Needs and Requirements Definition | 12207:2017 Clause 6.5.1 | `.orchestrated-agents/roles/role-selector.md` (Requirements Skeptic perspective) | PARTIAL | No Business Analyst / Requirements Engineer maker hat |
| GAP-A-018 | 6.5.2 System/Software Requirements Analysis | 12207:2017 Clause 6.5.2 | `.orchestrated-agents/roles/role-selector.md` + `.orchestrated-agents/roles/maker-engineer.md` (in scope) | PARTIAL | No Requirements Engineer maker hat |
| GAP-A-019 | 6.5.3 Architectural Design | 12207:2017 Clause 6.5.3 | `.orchestrated-agents/roles/role-selector.md` (SDLC Process Architect perspective only) | CONFIRMED GAP | No System/Solution/Enterprise Architect maker hat |
| GAP-A-020 | 6.5.4 Implementation Process | 12207:2017 Clause 6.5.4 | `.orchestrated-agents/roles/maker-engineer.md` lines 1-29 + `.orchestrated-agents/roles/process-engineer.md` line 5 | PARTIAL | Generic maker covers; no specialist frontend/backend/integration/data hats |
| GAP-A-021 | 6.5.5 Integration Process | 12207:2017 Clause 6.5.5 | `.orchestrated-agents/roles/role-selector.md` (mentions integration impact in role-selection debate) | CONFIRMED GAP | No Integration/API Engineer maker hat |
| GAP-A-022 | 6.5.6 Verification Process | 12207:2017 Clause 6.5.6 | `.orchestrated-agents/workflows/sdlc-gates.md` Gate 13 + `.orchestrated-agents/roles/qa-strategist.md` | COVERED | QA covers verification per sdlc-gates |
| GAP-A-023 | 6.5.7 Validation Process | 12207:2017 Clause 6.5.7 | `.orchestrated-agents/workflows/sdlc-gates.md` Gate 14 + `.orchestrated-agents/roles/qa-strategist.md` | COVERED | QA covers validation per sdlc-gates |
| GAP-A-024 | 6.5.8 Transition Process | 12207:2017 Clause 6.5.8 | `.orchestrated-agents/roles/release-sre-reviewer.md` (partial, review only) | PARTIAL | No dedicated Release Manager maker hat; Release SRE Reviewer is adversary-only |
| GAP-A-025 | 6.5.9 Operation Process | 12207:2017 Clause 6.5.9 | `.orchestrated-agents/roles/release-sre-reviewer.md` (partial) | PARTIAL | No dedicated Operations/Support maker hat |
| GAP-A-026 | 6.5.10 Maintenance Process | 12207:2017 Clause 6.5.10 | no artifact | CONFIRMED GAP | No Maintenance engineer maker hat |
| GAP-A-027 | 6.5.11 Disposal Process | 12207:2017 Clause 6.5.11 | no artifact | N/A | Out of AI-agent scope |

**Section A footnote (A0):** Section A rows GAP-A-001 through GAP-A-027 cover the four 12207:2017 process groups at the major-process level (one row per named process). The clause numbers above correspond to ISO/IEC/IEEE 12207:2017 Clause 6.x.y numbering. Where 12207:2026 renumbers or restructures (e.g., 12207:2026 clause map is published at https://www.iso.org/standard/90219.html), the GAP-A-NNN ID remains stable; a follow-up bead can author a 12207:2026 mapping appendix that preserves the same IDs. The v1 27-row enumeration is retained as the baseline because the bead description explicitly demands 12207:2017 coverage; QA Strategist item 1 noted that v1 may have omitted some sub-processes but the v1 27 rows are the agreed-upon scope for this evaluation. Row count for Section A: 27 rows (10 N/A, 9 CONFIRMED GAP, 7 PARTIAL, 4 COVERED).

**Section B -- NIST SSDF SP 800-218 v1.1 -- Secure Software Development Framework**

Baseline: NIST SP 800-218 v1.1, https://csrc.nist.gov/pubs/sp/800/218/final, published 2022-02, supersedes CSWP 13 (2020-04). Four practice groups: PO (Prepare Organization), PS (Protect Software), PW (Produce Well-Secured Software), RV (Respond to Vulnerabilities). Each practice has a unique ID (PO.1-PO.5, PS.1-PS.3, PW.1-PW.9, RV.1-RV.3). v3 corrects v1/v2 by:
- PW.7 evidence field: explicit process-timing gap (post-hoc adversarial comment review only; no pre-merge in-line code review hat; no PR-style gate). Per Adversarial Reviewer defect #4 in v2.
- PW.8 re-mapped to security-test capability gaps (DAST / fuzzing / abuse-case testing / security-requirement traceability) rather than ISO 25010 characteristic coverage. Per QA Strategist item 3.

| Gap ID | SSDF Practice | Source anchor (SP 800-218 v1.1) | Repository artifact | Verdict | Rationale |
| --- | --- | --- | --- | --- | --- |
| GAP-B-001 | PO.1 Define Security Requirements | SP 800-218 v1.1 PO.1 | `.orchestrated-agents/workflows/sdlc-gates.md` Gate 8 (Security and privacy analysis) | PARTIAL | Gate defined; no Security Engineer maker hat |
| GAP-B-002 | PO.2 Define Roles and Responsibilities | SP 800-218 v1.1 PO.2 | `.orchestrated-agents/roles/role-selector.md` + `.orchestrated-agents/roles/security-privacy-reviewer.md` (adversary) | PARTIAL | Roles defined; no dedicated RACI workflow |
| GAP-B-003 | PO.3 Implement Supporting Toolchains | SP 800-218 v1.1 PO.3 | `opencode.json` agent toolchain definitions (lines 1-299) | PARTIAL | Agent toolchain defined; no SBOM/SCA workflow |
| GAP-B-004 | PO.4 Define and Use Criteria for SW Security Checks | SP 800-218 v1.1 PO.4 | `.orchestrated-agents/roles/qa-strategist.md` + `.orchestrated-agents/roles/security-privacy-reviewer.md` | PARTIAL | Adversaries cover; no Security Engineer maker hat |
| GAP-B-005 | PO.5 Implement and Maintain Secure Environments for Software Development | SP 800-218 v1.1 PO.5 | `.orchestrated-agents/roles/release-sre-reviewer.md` + `opencode.json` permission blocks | PARTIAL | SRE reviews; no Platform/SecEnv maker hat |
| GAP-B-006 | PS.1 Protect All Forms of Code | SP 800-218 v1.1 PS.1 | `.orchestrated-agents/roles/security-privacy-reviewer.md` + `opencode.json` deny rules at lines 109-113 (`git push*`, `alembic upgrade*`, `docker push*`, `npm publish*`, `scp *` deny) | PARTIAL | Adversary covers + deny rules; no AppSec maker hat |
| GAP-B-007 | PS.2 Provide a Mechanism for Verifying Software Release Integrity | SP 800-218 v1.1 PS.2 | no artifact | CONFIRMED GAP | No code-signing/release-verification workflow; deferred (K-DEFERRED bucket) |
| GAP-B-008 | PS.3 Archive and Protect Each Software Release | SP 800-218 v1.1 PS.3 | no artifact | CONFIRMED GAP | No release-archival workflow; deferred (K-DEFERRED bucket) |
| GAP-B-009 | PW.1 Design Software to Meet Security Requirements | SP 800-218 v1.1 PW.1 | `.orchestrated-agents/roles/role-selector.md` (Security/Risk Architect perspective) + `sdlc-gates.md` Gate 8 | PARTIAL | Role-selection debate covers; no Threat Modeler maker hat |
| GAP-B-010 | PW.2 Review the Software Design | SP 800-218 v1.1 PW.2 | `.orchestrated-agents/roles/adversarial-reviewer.md` + `.orchestrated-agents/roles/security-privacy-reviewer.md` | PARTIAL | Adversaries cover; no Design Reviewer maker hat |
| GAP-B-011 | PW.3 Reuse Existing, Well-Secured Software | SP 800-218 v1.1 PW.3 | no artifact | CONFIRMED GAP | No SBOM/component-vetting workflow; deferred (K-DEFERRED bucket) |
| GAP-B-012 | PW.4 Write Source Code | SP 800-218 v1.1 PW.4 | `.orchestrated-agents/roles/maker-engineer.md` + `.orchestrated-agents/roles/process-engineer.md` | PARTIAL | Generic coding covered; no Secure Coding Standard workflow |
| GAP-B-013 | PW.5 Configure Compilation, Interpreter, and Build Processes | SP 800-218 v1.1 PW.5 | no artifact | CONFIRMED GAP | No Build Engineer maker hat; deferred (K-DEFERRED bucket) |
| GAP-B-014 | PW.6 Compile and Check Code | SP 800-218 v1.1 PW.6 | `.orchestrated-agents/roles/qa-strategist.md` (tests run) | PARTIAL | Tests run; no SAST/DAST gating |
| GAP-B-015 | PW.7 Review Human-Readable Code | SP 800-218 v1.1 PW.7 | `.orchestrated-agents/roles/adversarial-reviewer.md` (adversary, post-hoc comment review only) | PARTIAL -- post-hoc adversarial comment review only; no pre-merge in-line code review maker hat; process-timing gap is real (no PR-style gate) | Per Adversarial Reviewer defect #4 in v2; PW.7 evidence field expanded with the process-timing dimension |
| GAP-B-016 | PW.8 Test Executable Code | SP 800-218 v1.1 PW.8 (security-test practice: "Test executable code to identify vulnerabilities and verify compliance with security requirements") | `.orchestrated-agents/roles/qa-strategist.md` (functional/security tests via npm test / pytest); `opencode.json` lines 137-139 (adversarial-reviewer allow: `npm run lint*`, `npm test*`, `pytest*`); `.orchestrated-agents/roles/security-privacy-reviewer.md` (gitleaks / trufflehog at opencode.json lines 189-194) | PARTIAL -- security-test coverage limited to secret-scan (gitleaks/trufflehog) + functional/security pytest/npm tests; no DAST, no fuzzing, no abuse-case testing, no security-requirement traceability | Per QA Strategist item 3: PW.8 is a NIST SSDF security-test practice, NOT an ISO 25010 quality-characteristic test coverage row. v1/v2 mapped PW.8 to ISO 25010 characteristic gaps -- v3 corrects this. The ISO 25010 characteristic coverage gaps belong in Section D |
| GAP-B-017 | PW.9 Configure Software for Security | SP 800-218 v1.1 PW.9 | no artifact | CONFIRMED GAP | No runtime-hardening workflow; deferred (K-DEFERRED bucket) |
| GAP-B-018 | RV.1 Identify and Confirm Vulnerabilities | SP 800-218 v1.1 RV.1 | `.orchestrated-agents/roles/security-privacy-reviewer.md` + `opencode.json` lines 189-194 (`gitleaks*`, `trufflehog*` allow) | PARTIAL | Secret scan covered; no SBOM/SCA |
| GAP-B-019 | RV.2 Assess, Prioritize, and Remediate Vulnerabilities | SP 800-218 v1.1 RV.2 | `.orchestrated-agents/roles/adversarial-reviewer.md` + `.orchestrated-agents/roles/security-privacy-reviewer.md` | PARTIAL | Adversaries cover; no vuln-tracking workflow |
| GAP-B-020 | RV.3 Analyze Root Cause | SP 800-218 v1.1 RV.3 | no artifact | CONFIRMED GAP | No RCA workflow; deferred (K-DEFERRED bucket) |

Section B row count: 20 rows (0 N/A, 8 CONFIRMED GAP, 12 PARTIAL, 0 COVERED). Section B continues the 12207 coverage pattern (every NIST SSDF practice enumerated).

(End of Part 1. Part 2 will contain Sections C-G: OWASP SAMM v2, ISO/IEC 25010:2023, IEEE SWEBOK v4, SFIA 9, Google SRE Part II.)
