## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-007 (line 328) BLOCKER. Architect specialist required per 12207 6.5.3 Architectural Design + SWEBOK Ch.2 + SAMM Design.Secure Architecture + SFIA Strategy and Architecture + active LangGraph runtime.

## Actual Task
Create:
1. `.orchestrated-agents/roles/architect.md` -- specialist maker hat charter covering LangGraph runtime architecture + design documentation + ADRs
2. `oa-architect` agent in `opencode.json` with stack-tagged `edit.permission` (`*`: deny, `implementation-plan/**`: allow, `AGENTS.md`: allow, env files deny) + read-only access to all product code (via bash allow for cat / rg / git status etc. but no edit rights to fb_dash/ or fb_agent/)
3. Per-role permission smoke-test entry
4. Wire role display-name `Architect` into `oa.ps1`

## Dependencies
Depends on GAP-J-F4 (socialhub-v8g.12). No specialist-maker make-edit rights - the Architect is documentation-only and cannot edit product code (product-code edits go through Frontend/Backend/Integration/Data/etc.).

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the read-only-product-code pattern is enforced (no fb_dash/ or fb_agent/ in edit.permission allow).
- QA Strategist verifies smoke-test passes for the read-only commands.
- Documentation Reviewer confirms the architect role-charter is linked from AGENTS.md.
- The new role can be invoked via oa.cmd run.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 328.
- AGENTS_ARCHITECTURE_DESIGN.md: eleven hidden domain-agent nodes/subgraphs.
- implementation-plan/NEXLAB_LANGGRAPH_FULL_REBUILD_PLAN.md.

## Why This Is Useful
Without an Architect specialist hat, architectural decisions are made by ad-hoc role assignment. LangGraph runtime architecture touches every product bead, and a dedicated architect role ensures consistency. The read-only restriction (documentation only) prevents architectural drift from becoming direct product-code edits without adversarial review.