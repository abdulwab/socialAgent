### Commentor: Process Engineer

**Step/Subtask:** C4-alpha/beta/gamma/delta remediation -- four-defect follow-up pass addressing the Adversarial Reviewer's 13:56Z Needs Fix

**Status:** Evidence Accepted

**Findings:**

All four C4 sub-defects identified by the Adversarial Reviewer at 2026-07-13T13:56:39Z have been fixed and verified empirically. Additionally, a root-cause defect beyond the four prescribed was found and fixed: the double-dash `--` prefix used in ALL documentation examples is PowerShell 5.1's stop-parsing token, so NO documented invocation path worked as written (not just the hyphenated forms). All examples were rewritten to single-dash `-` syntax.

**C4-alpha (HIGH) -- FIXED.** Added `[Alias('bead-id')]` to `$BeadId` and `[Alias('comment-id')]` to `$CommentId` in test-comment-check.ps1 lines 59/62. Empirically verified: `-bead-id "socialhub-v8g.22.44" -comment-id "abc123" -author "Role Selector"` binds bead_id, comment_id, and author to the correct JSON fields with no garbling. The Adversarial Reviewer also identified that `--` (double-dash) is the root cause of the metadata garbling -- this is correct and broader than just the hyphenated names: PowerShell treats `--` as the stop-parsing token, so `--text`, `--bead-id`, `--stdin`, and `--author` ALL fail (not just the hyphenated ones). The Adversarial Reviewer's observation that "core probe detection via the Text parameter works" was because those tests used splatting, not the documented `--text` syntax. All documentation examples across three files were rewritten to single-dash.

**C4-beta (HIGH) -- FIXED.** Reordered the text-resolution logic in test-comment-check.ps1 end block: `$Script:SawPipelineInput` (pipeline accumulator) is now checked BEFORE `$Stdin` (`[Console]::In.ReadToEnd()`). When both piped input and `-stdin` are present, the piped data binds to `$InputObject` in the process block and `[Console]::In` is already drained. Empirically verified: a valid 300+ char Markdown comment piped via `$comment | linter -stdin -bead-id X -author Y` exits 0 with `valid=true`, `bead_id` correctly bound, and no empty-text usage error.

**C4-gamma (HIGH) -- FIXED (option b: honest characterization).** Rewrote the two overclaims in bead-protocol.md. (1) "Why a self-check" section: replaced "turns the rule into a hard pre-condition" with honest text stating the linter is NOT a wrapper-level gate, the current architecture does not intercept `bd comment` tool calls inside the agent subprocess, true wrapper-level enforcement (pre-tool hook or shim) is deferred, and the residual risk is documented. (2) "Mitigation that the violation motivates" section: replaced "This converts the prose rule into a hard pre-condition" with the same honest characterization of self-check responsibility, detectable-but-not-vetoable invocation, and deferred wrapper-level interception. The Adversarial Reviewer accepted option (b) as adequate for this bead if the architecture constraint is real; the constraint IS real (the wrapper spawns `opencode run` in auto mode and cannot observe or veto tool calls inside the subprocess).

**C4-delta (MEDIUM) -- FIXED.** Removed the bare `test with` phrase from the probe-phrase list in test-comment-check.ps1 (line 161-172 array), bead-protocol.md "What the linter checks" section, and oa.ps1 line 641 prompt. Empirically verified two ways: (a) a legitimate compliant comment containing the prose "running a test with the production configuration" now exits 0 (was previously falsely rejected); (b) the historical probe `test with <id> and <pattern>` is still rejected (exit 1) via the structure, length (< 200 chars), and density (<= 2 non-blank lines) checks. The bd-cli-quirks.md smoke-test case #5 expected output was updated to document this.

**Full smoke test (7 cases, all PASS):**

| Case | Pattern | Exit | Expect |
| --- | --- | --- | --- |
| 1 | `test probe` | 1 | 1 |
| 2 | `line1\nline2\nline3` | 1 | 1 |
| 3 | `Test line 1\nTest line 2\nTest line 3` | 1 | 1 |
| 4 | `hello world` | 1 | 1 |
| 5 | `test with <id> and <pattern>` | 1 | 1 |
| 6 | `lineA\nlineB\nlineC with <id> literal` | 1 | 1 |
| 7 | compliant control (300+ char formatted Markdown) | 0 | 0 |

**Evidence:** Direct invocation of test-comment-check.ps1 with single-dash syntax for all 7 smoke-test cases plus metadata-binding verification and C4-delta false-positive verification. `bd show socialhub-v8g.22.44 --json` after `bd update --assignee "Process Engineer" --status in_progress` at start of this turn. `git status --short` and file line-count verification.

**Verified Evidence:**

- `bd show socialhub-v8g.22.44 --json at 2026-07-13T14:04:42Z` -> slice: `{ id: socialhub-v8g.22.44, status: in_progress, priority: 1, assignee: Process Engineer, updated_at: 2026-07-13T14:04:42Z, parent: socialhub-v8g.22 }`. Confirms Process Engineer is current assignee (re-assigned via `bd update --assignee "Process Engineer" --status in_progress` at start of this turn); status in_progress held; P1 priority held; parent socialhub-v8g.22 (P0 epic) held.

- Linter metadata binding (C4-alpha): `-bead-id "socialhub-v8g.22.44" -comment-id "abc123" -author "Role Selector"` -> JSON bead_id="socialhub-v8g.22.44", comment_id="abc123", author="Role Selector", valid=false. No garbling. External tool evidence (linter stdout).

- Pipe-stdin path (C4-beta): valid comment piped -> valid=true, bead_id="socialhub-v8g.22.44", exit=0. External tool evidence (linter stdout).

- C4-delta false-positive removal: compliant comment containing "running a test with the production configuration" -> valid=true, exit=0. External tool evidence (linter stdout).

**Required Next Action:**

Hand off to **Adversarial Reviewer** for re-review of the C4-alpha/beta/gamma/delta fixes. The Adversarial Reviewer MUST verify by running all three documented invocation paths (variable, pipe-stdin, here-string) with single-dash syntax and confirming correct exit codes + clean metadata:

1. **C4-alpha:** Run `-text "test probe" -bead-id <id> -comment-id <id> -author <name>` and confirm bead_id/comment_id/author fields hold correct values (not garbled). Also confirm the double-dash `--` form fails (it is PowerShell's stop-parsing token).
2. **C4-beta:** Pipe a valid 300+ char comment via `$comment | linter -stdin -bead-id <id> -author <name>` and confirm exit 0 with valid=true.
3. **C4-gamma:** Read bead-protocol.md "Why a self-check" section and "Mitigation that the violation motivates" section -- confirm no "hard pre-condition" overclaim remains; confirm the honest self-check characterization is present.
4. **C4-delta:** Pipe a compliant comment containing the prose "test with" and confirm exit 0. Run probe #5 (`test with <id> and <pattern>`) and confirm exit 1 via structure/length/density (NOT via probe phrase).

After Adversarial Reviewer re-approves, the convergence chain proceeds: QA Strategist (full 7-case smoke test + H2/H3 checks), Documentation Reviewer (cross-links), Workflow Scout (Meta + WFSC-bead-7/8 filing), Role Selector (close with convergence validation).

**Bead status note:** I am NOT setting the bead status to closed. Process Engineer is only one of the required sign-offs (per bead-protocol.md Forbidden Shortcuts). The bead remains `in_progress` until all required sign-offs converge.
