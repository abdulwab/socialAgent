## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section L GAP-L-005 (line 368) CONFIRMED GAP. Routing-decision question: How does the framework handle confirmation interrupts for risky actions (publishing, deletion, scheduling, OAuth, schema migrations, dependency upgrades, force-push, container push)?

## Actual Task
Author:
1. `.orchestrated-agents/workflows/confirmation-interrupts.md` -- codifies the confirmation-interrupt flow. Specifies: which actions require confirmation (publishing, scheduling, deletion, disconnect, bulk retry, draft overwrite, autopilot mutations per AGENTS.md Safety and Protected Changes); how the interrupt is surfaced to the operator; what the operator must confirm (one-time explicit); how the confirmation is logged to Beads (a confirmation comment with operator name + timestamp + action hash).
2. `.orchestrated-agents/templates/confirmation-prompt.md` -- per-bead confirmation gating template (operator fills in action, target artifact, expected impact, then signs off).
3. Cross-link from `.orchestrated-agents/docs/CONTEXT.md` Secret Handling + Safety and Protected Changes sections.

## Dependencies
Pairs with GAP-K-005 (Security Engineer). The existing oa-maker-engineer deny rules (opencode.json lines 101 + 109-113) provide prevention for some destructive operations; the confirmation-interrupt flow handles the operations that are not blanket-denied but still require operator approval.

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the confirmation-interrupt flow is consistent with AGENTS.md Safety and Protected Changes list.
- QA Strategist verifies the confirmation-prompt template produces a valid confirmation record.
- Security Privacy Reviewer confirms the confirmation record is auditable (operator name, timestamp, action hash).
- Documentation Reviewer confirms the new workflow file is linked from CONTEXT.md and is understandable by operators.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 368 (GAP-L-005 row).
- AGENTS.md Safety and Protected Changes section.
- opencode.json lines 101 + 109-113 (existing deny rules).

## Why This Is Useful
Per Adversarial Reviewer defect #7 (v2): no maker hat owns the confirmation flow. The deny rules prevent some unsafe operations but not all; confirmation interrupts are needed for operations that are conditionally allowed but require operator approval. Closing GAP-L-005 codifies the confirmation flow so it is consistently applied across all risky-action beads.