## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-011 (line 332) BLOCKER. Accessibility Tester required per ISO 25010:2023 GAP-D-004 Interaction Capability + WCAG 2.2 AA + AGENTS.md user-facing UI.

## Actual Task
Create:
1. `.orchestrated-agents/roles/a11y-tester.md` -- specialist maker hat charter covering WCAG 2.2 AA + accessibility testing patterns + screen reader verification + keyboard navigation tests
2. `oa-a11y-tester` agent in `opencode.json` with stack-tagged `edit.permission` (`*`: deny, `fb_dash/**`: allow, env files deny) + bash allow for `axe *`, `pa11y *`
3. Per-role permission smoke-test entry
4. Wire role display-name `Accessibility Tester` into `oa.ps1`

## Dependencies
Depends on GAP-K-001 (Frontend Engineer) = socialhub-v8g.22.7.

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the broad fb_dash/ allowlist is correct (a11y tester may need to inspect all UI components).
- QA Strategist verifies smoke-test passes for axe and pa11y.
- Documentation Reviewer confirms WCAG 2.2 AA coverage is documented.
- The new role can be invoked via oa.cmd run.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 332.
- ISO 25010:2023 GAP-D-004 Interaction Capability.
- WCAG 2.2 AA.
- AGENTS.md user-facing UI requirements.

## Why This Is Useful
Without an Accessibility Tester specialist hat, accessibility is folded into QA Strategist (adversary) but the QA Strategist cannot run axe/pa11y (no bash allow). Closing GAP-K-011 provides a dedicated a11y testing maker hat with the appropriate bash allowlist. The role pairs with GAP-K-016 (UX Designer) for a11y-aware design and with GAP-K-001 (Frontend Engineer) for a11y-aware implementation.