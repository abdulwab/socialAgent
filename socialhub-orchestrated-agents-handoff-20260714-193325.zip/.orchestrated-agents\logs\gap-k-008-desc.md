## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-008 (line 329) BLOCKER. DevOps specialist required per 12207 6.5.8 Transition + SRE Book Ch.8 + AGENTS.md Backend deployment story (Docker + SCP + socialhub-api container + /home/ubuntu/fb_agent/.env).

## Actual Task
Create:
1. `.orchestrated-agents/roles/devops-engineer.md` -- specialist maker hat charter covering Docker + SCP + production deploy + Dockerfile authoring
2. `oa-devops-engineer` agent in `opencode.json` with stack-tagged `edit.permission` (`*`: deny, `Dockerfile`: allow, `docker-compose*.yml`: allow, `fb_agent/Dockerfile`: allow, env files deny) + bash allow for `docker *`, `scp *`
3. Per-role permission smoke-test entry
4. Wire role display-name `DevOps Engineer` into `oa.ps1`

## Dependencies
Depends on GAP-J-F4 (socialhub-v8g.12).

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the multi-path allowlist (Dockerfile + docker-compose + fb_agent/Dockerfile) + bash allowlist (docker + scp) is correct and does not include `docker push*` or `scp * production*` without confirmation.
- QA Strategist verifies smoke-test passes for the docker and scp commands.
- Security Privacy Reviewer confirms AGENTS.md Safety rule (production deployment requires explicit approval).
- The new role can be invoked via oa.cmd run.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 329.
- AGENTS.md Backend section: production uses approved SCP transfer and Docker rebuild with container socialhub-api and /home/ubuntu/fb_agent/.env.
- AGENTS.md Safety and Protected Changes: deployment and final legacy deletion require explicit approval.
- AGENTS.md Backend changes are never pushed to GitHub.

## Why This Is Useful
Without a DevOps specialist hat, deployment is performed by ad-hoc Maker Engineer invocations, which violates the AGENTS.md Safety rule (production deployment requires explicit approval). Closing GAP-K-008 routes deployment through a dedicated role that has bash allow for docker/scp but maintains the deny rules for production-destructive operations. The role also documents the production deployment story for future contributors.