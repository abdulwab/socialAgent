## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-IMP-001 (line 342) IMPROVEMENT. Per Adversarial Reviewer defect #10 (v2): the Configuration Manager hat is reclassified from BLOCKER to IMPROVEMENT because the AGENTS.md Safety rule is already enforced by `oa-maker-engineer` deny rules in `opencode.json` lines 101 + 109-113.

## Actual Task
Create:
1. `.orchestrated-agents/roles/configuration-manager.md` -- specialist maker hat charter covering configuration audit + change-tracking + per-hat ownership + configuration-as-code patterns
2. `oa-configuration-manager` agent in `opencode.json` with READ-ONLY access to `opencode.json` (no edit permissions on any file, including opencode.json; this is the audit role) + bash allow for `git status*`, `git diff*`, `git log*`, `bd show*`
3. Per-role permission smoke-test entry
4. Wire role display-name `Configuration Manager` into `oa.ps1`

## Dependencies
Depends on GAP-J-F4 (socialhub-v8g.12).

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the read-only-on-everything pattern is enforced (no edit.permission allow paths).
- QA Strategist verifies smoke-test passes for git status/diff/log and bd show.
- Documentation Reviewer confirms the role-charter is linked from AGENTS.md Configuration Management section.
- The new role can be invoked via oa.cmd run.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 342 (GAP-K-IMP-001 IMPROVEMENT row).
- opencode.json lines 101 + 109-113: existing deny rules for oa-maker-engineer that already enforce AGENTS.md Safety rule.
- 12207 6.4.5 Configuration Management.
- AGENTS.md Safety and Protected Changes.

## Why This Is Useful
Per Adversarial Reviewer defect #10 (v2): the existing deny rules in oa-maker-engineer (opencode.json lines 101 + 109-113) already enforce AGENTS.md Safety rule for the listed unsafe operations. So Configuration Manager is NOT a current readiness blocker; it is an improvement for specialist ownership + audit trail + per-hat ownership. The role can wait one cycle without blocking product-code readiness.

## Reclassification rationale (from matrix Section K intro)
'Per Adversarial Reviewer defect #10 (v2): the deny rules exist so not a current readiness blocker; specialist ownership + audit trail + per-hat ownership are an improvement.'