## Context
The v5 hygiene cleanup bead bundles the 14 v5 hygiene items raised across 4 roles during the socialhub-v8g.22.1 v4 convergence: 5 items from Adversarial Reviewer + QA Strategist combined, 6 items from Documentation Reviewer, and 3 items elevated by Security Privacy Reviewer. Per QA Strategist 23:57Z Required Next Action and SPR 2026-07-13 00:07Z Required Next Action and DR 2026-07-13 00:14Z Required Next Action.

## Actual Task
Implement all 14 v5 hygiene items in a single Process Engineer pass. The items are:

### 5 AR/QA items (raised during v3/v4 re-review)
1. AR defect #1 fix applied in v4 (Section A summary tally arithmetic correction 5/7/11/4 = 27)
2. AR defect #2 fix applied in v4 (Section B summary tally arithmetic correction 6/14 = 20)
3. AR defect #3 fix applied in v4 (Section L summary tally arithmetic correction 4/2 = 6)
4. AR defect #4 fix applied in v4 (opencode.json deny-rule line-range imprecision correction: lines 101 + 109-113)
5. QA-Defect #5 evidence-portability improvement applied in v4 (materialize as canonical doc + CONTEXT.md link)

### 6 DR items (raised during deliverability pass)
6. DR: confirm v4 canonical is portable-where-promised (no machine-specific paths in the canonical doc)
7. DR: confirm v4 canonical is linkable from CONTEXT.md without secrets (already linked at .orchestrated-agents/docs/CONTEXT.md Authoritative Documents section)
8. DR: confirm v4 canonical is understandable by future readers (Section N conformance statement + Section 0 conventions)
9. DR: confirm v4 canonical is copyable (no proprietary formatting, pure Markdown)
10. DR: confirm v4 canonical is accurate for the current repo (v4 corrections applied to v3 substance; no fabrication)
11. DR: confirm v4 canonical is free of secrets (no API keys, tokens, env-var values, etc.)

### 3 SPR-elevated items (raised during security/privacy boundary pass)
12. SPR: GAP-J-6 (per-role bash permission blocks) provenance disclosure is consistent across all 9 non-maker roles
13. SPR: GAP-K-013 (Standards Research Analyst) bash-allow narrowing (curl/webfetch allow should be more restrictive to prevent exfiltration)
14. SPR: oa-process-engineer deny-rule asymmetry (the deny rules for *.env files use 5 separate patterns; could be consolidated to a single .env* pattern)

## Why This Is Useful
These 14 items are documented in bead comments but not yet implemented as a coordinated hygiene pass. Closing GAP-K-IMP-002 implements them in a single Process Engineer pass so the framework reaches v5 hygiene cleanliness. The cleanup bead can be worked AFTER the first implementation batches land (per Codex-Orchestrator 2026-07-13 10:42Z: 'File one v5 hygiene cleanup bead for the AR/QA/SPR/DR hygiene bundle, to run after the first implementation batches so cleanup reflects what actually lands').

## Implementation Approach
Single Process Engineer pass with the following steps:
1. Update .orchestrated-agents/docs/coverage-matrix-v3.md with any post-v4 corrections discovered during the first implementation batches.
2. Update .orchestrated-agents/docs/CONTEXT.md if any cross-references need updating.
3. Update .orchestrated-agents/workflows/bead-protocol.md with the WFSC-bead-2 canonical-deliverable placement rule (if not already done by socialhub-v8g.22.3 implementation).
4. Update .orchestrated-agents/roles/process-engineer.md with the stack-tagged template documentation (per GAP-L-003).
5. Run a full v5 hygiene audit using a checklist that verifies each of the 14 items is implemented.
6. Post a v5 hygiene confirmation comment on socialhub-v8g.22.1 citing each of the 14 items.

## Dependencies
None (this is post-implementation cleanup). Per Codex-Orchestrator 2026-07-13 10:42Z: 'File one v5 hygiene cleanup bead for the AR/QA/SPR/DR hygiene bundle, to run after the first implementation batches so cleanup reflects what actually lands.'

## Acceptance Criteria
- All 14 items are implemented and verifiable.
- Process Engineer files a v5 hygiene confirmation comment on socialhub-v8g.22.1 citing each of the 14 items with file/line references.
- Adversarial Reviewer verifies the 5 AR/QA items are correctly applied.
- Documentation Reviewer verifies the 6 DR items are correctly applied.
- Security Privacy Reviewer verifies the 3 SPR-elevated items are correctly applied.
- QA Strategist verifies the v5 hygiene audit checklist is complete.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md v4 Delta at lines 446-505 (the 5 v4 corrections).
- socialhub-v8g.22.1 Adversarial Reviewer v4 Parts 1-3 (23:47-48Z): the 4 AR-flagged defects.
- socialhub-v8g.22.1 QA Strategist v4 (23:56-57Z): the 5 AR/QA v5 hygiene items.
- socialhub-v8g.22.1 Security Privacy Reviewer Parts 1-2 (2026-07-13 00:06-07Z): the 3 SPR-elevated items.
- socialhub-v8g.22.1 Documentation Reviewer (2026-07-13 00:14Z): the 6 DR hygiene items.
- Codex-Orchestrator 2026-07-13 10:42Z: v5 hygiene cleanup bead sequenced last per Option C.

## Stable ID
GAP-K-IMP-002 (per Process Engineer 2026-07-13 10:40Z suggestion and per Codex-Orchestrator 2026-07-13 10:42Z implementation order).