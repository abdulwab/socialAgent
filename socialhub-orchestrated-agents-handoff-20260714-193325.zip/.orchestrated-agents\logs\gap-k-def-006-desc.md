## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-DEF-006 (line 350) DEFERRED. Per Section 0.6(a): current dependency footprint is small (FastAPI, Next.js, Clerk, LangGraph, LangSmith, Z.AI GLM); SBOM/SCA adds value when dependency surface grows.

## Actual Task
DEFERRED: Author `.orchestrated-agents/workflows/sbom-sca.md` when dependency count exceeds 50. The workflow covers NIST SSDF PW.3 Reuse Existing Well-Secured Software + SBOM/SCA tooling.

## Dependencies
Promote when dependency count exceeds 50 (current footprint is well below 50).

## Acceptance Criteria (for promotion)
- Trigger: dependency count exceeds 50 (track via package.json + requirements.txt).
- Process Engineer files the promotion bead (this GAP-K-DEF-006 transitions to CONFIRMED GAP / BLOCKER).

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 350 (GAP-K-DEF-006 DEFERRED row).
- NIST SSDF PW.3.

## Why Deferred
Per 0.6(a): SBOM/SCA tooling adds value only when the dependency surface is large enough to warrant automated scanning. At current SocialHub scale, ad-hoc dependency review is sufficient.