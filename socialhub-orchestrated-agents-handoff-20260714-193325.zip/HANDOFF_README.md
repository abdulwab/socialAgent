﻿# SocialHub Orchestrated Agents Handoff

Created: 2026-07-14 19:33:26 +05:00
Source repo: C:\Users\alvil\Desktop\code\socialhub

## What is included

- .orchestrated-agents/**: workflow, roles, templates, scripts, docs, and logs.
- opencode.json: role runner and model/provider setup using environment variables only.
- AGENTS.md, CLAUDE.md, .agent/**, .agents/**, .codex/**, .claude/settings.json: agent instructions and hook setup.
- .beads/issues.jsonl, .beads/interactions.jsonl, .beads/config.yaml, .beads/hooks/**, and Beads metadata/readme files.

## What is intentionally excluded

- API keys, .env files, and secret files.
- .beads/embeddeddolt/** local binary DB/cache.
- .beads/backup/** local backup blobs.
- Product app source folders unrelated to the orchestration package.

## Resume notes

1. Unzip at the root of the target socialhub checkout.
2. Keep using Beads d version 1.0.4 unless a later bead changes that decision.
3. Set AI keys as environment variables only, such as ZAI_API_KEY or MINIMAX_API_KEY.
4. Start from .orchestrated-agents/WORKFLOW.md for the simple shared workflow reference.
5. Run d prime to load Beads context after setup.
6. Use .orchestrated-agents/bin/oa.ps1 for role runs on Windows.
