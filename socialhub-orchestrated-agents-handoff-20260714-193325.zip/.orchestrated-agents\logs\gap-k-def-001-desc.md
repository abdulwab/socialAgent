## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-DEF-001 (line 345) DEFERRED. Per Section 0.6(a): capability does not block product-code readiness today; will be promoted to CONFIRMED GAP at first production incident.

## Actual Task
DEFERRED: Create `.orchestrated-agents/roles/incident-commander.md` when first production incident occurs. The role covers SRE Part II Ch.13 Emergency Response + Ch.14 Managing Incidents + Ch.15 Postmortem Culture.

## Dependencies
Promote at first production incident; pairs with GAP-K-009 (SRE Engineer) = socialhub-v8g.22.15.

## Acceptance Criteria (for promotion)
- Trigger: first production incident is declared.
- Process Engineer files the promotion bead (this GAP-K-DEF-001 transitions to CONFIRMED GAP / BLOCKER).
- Role Selector debate runs on the promotion bead.
- Implementation follows the standard role-creation lifecycle.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 345 (GAP-K-DEF-001 DEFERRED row).
- SRE Part II Ch.13 Emergency Response + Ch.14 Managing Incidents + Ch.15 Postmortem Culture.

## Why Deferred
Per 0.6(a): incident commander capability does not block product-code readiness at current SocialHub scale. The Release SRE Reviewer (adversary) can handle post-incident review until the first production incident occurs; at that point, an Incident Commander maker hat is needed to drive the actual incident response.

## Reclassification trigger
The first time a SocialHub production incident is declared, this bead should be promoted from DEFERRED to BLOCKER. The promotion criterion: any production-impacting event that requires coordinated multi-role response.