## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-DEF-007 (line 351) DEFERRED. Per Section 0.6(a): DevOps Engineer (GAP-K-008) covers the build pipeline; dedicated Build Engineer adds value only with multi-target build matrix.

## Actual Task
DEFERRED: Create `.orchestrated-agents/roles/build-engineer.md` with multi-target build matrix. The role covers NIST SSDF PW.5 Configure Compilation + Build Processes + 12207 6.5.4 Implementation (build pipeline).

## Dependencies
Promote with multi-target build matrix (e.g., when the build pipeline must produce binaries for multiple platforms or multiple deployment targets). Currently GAP-K-008 (DevOps Engineer) covers the build pipeline.

## Acceptance Criteria (for promotion)
- Trigger: multi-target build matrix is required.
- Process Engineer files the promotion bead (this GAP-K-DEF-007 transitions to CONFIRMED GAP / BLOCKER).

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 351 (GAP-K-DEF-007 DEFERRED row).
- NIST SSDF PW.5.

## Why Deferred
Per 0.6(a): the existing deny rules in oa-maker-engineer (opencode.json lines 101 + 109-113) prevent unsafe build ops but do not define the build pipeline itself. The DevOps Engineer (GAP-K-008) covers the build pipeline at current scale. A dedicated Build Engineer adds value only with multi-target build matrix.