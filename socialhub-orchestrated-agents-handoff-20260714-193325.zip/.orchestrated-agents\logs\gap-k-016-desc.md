## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section K GAP-K-016 (line 337) BLOCKER. UX Designer required per ISO 25010:2023 GAP-D-004 Interaction Capability + SWEBOK Ch.3 Software Design (UI Design sub-area) + AGENTS.md user-facing UI.

## Actual Task
Create:
1. `.orchestrated-agents/roles/ux-designer.md` -- specialist maker hat charter covering UI/UX design + interaction patterns + user research + accessibility-aware design + design tokens
2. `oa-ux-designer` agent in `opencode.json` with stack-tagged `edit.permission` (`*`: deny, `fb_dash/app/**`: allow, `fb_dash/components/**`: allow, env files deny)
3. Per-role permission smoke-test entry
4. Wire role display-name `UX Designer` into `oa.ps1`

## Dependencies
Depends on GAP-K-001 (Frontend Engineer) = socialhub-v8g.22.7. Pairs with GAP-K-011 (Accessibility Tester).

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the two-path allowlist (fb_dash/app + fb_dash/components) is correct.
- QA Strategist verifies smoke-test passes.
- Documentation Reviewer confirms design tokens and interaction patterns are documented.
- The new role can be invoked via oa.cmd run.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 337.
- ISO 25010:2023 GAP-D-004 Interaction Capability.
- SWEBOK Ch.3 Software Design (UI Design sub-area).
- AGENTS.md user-facing UI.

## Why This Is Useful
Without a UX Designer specialist hat, UI/UX design is folded into Role Selector (process architect role). Closing GAP-K-016 provides a dedicated UX designer maker hat that owns the UI/UX design inputs to each frontend bead. The role pairs with GAP-K-001 (Frontend Engineer) for design-aware implementation and with GAP-K-011 (Accessibility Tester) for accessibility-aware design.