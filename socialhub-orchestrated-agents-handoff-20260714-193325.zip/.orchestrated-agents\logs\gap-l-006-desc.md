## Context
Canonical matrix `.orchestrated-agents/docs/coverage-matrix-v3.md` Section L GAP-L-006 (line 369) PARTIAL. Routing-decision question: How does the framework record per-bead SDLC gate evidence uniformly?

## Actual Task
Author:
1. `.orchestrated-agents/templates/sdlc-gate-matrix.md` -- uniform per-bead gate matrix template. Lists all 20 SDLC gates with Applicability (Applicable / Not Applicable / Already Satisfied), Required Roles, Evidence Expected, Skip Reason fields. Each bead must fill out this matrix and reference it from the bead description.
2. Bind to `.orchestrated-agents/templates/comment.md` -- every role comment on a bead must include a 'Gate Matrix Reference' line that points to the bead's filled-out gate matrix.
3. Reference the new template from `.orchestrated-agents/workflows/sdlc-gates.md` Gate 13 (Verification strategy, applicable to every bead).

## Dependencies
Complements existing sdlc-gates.md Gate 13.

## Acceptance Criteria
- Role Selector debate runs.
- Process Engineer implements after convergence.
- Adversarial Reviewer confirms the gate matrix template is exhaustive (every gate has a row) and the Applicability field has clear criteria for Applicable / Not Applicable / Already Satisfied.
- QA Strategist verifies the template produces a consistent matrix across sample beads.
- Documentation Reviewer confirms the template is linked from CONTEXT.md and from the comment template.

## References
- .orchestrated-agents/docs/coverage-matrix-v3.md line 369 (GAP-L-006 row).
- .orchestrated-agents/workflows/sdlc-gates.md Gate 13.
- .orchestrated-agents/templates/comment.md (existing comment template).

## Why This Is Useful
Currently per-bead SDLC gate evidence is comment-by-comment (each role comment records its own gate coverage). Closing GAP-L-006 creates a uniform gate-matrix template that every bead uses, making it easy to compare gate coverage across beads and identify systematic gaps. The 'Gate Matrix Reference' line in every comment ensures the matrix is discoverable from the comment trail.